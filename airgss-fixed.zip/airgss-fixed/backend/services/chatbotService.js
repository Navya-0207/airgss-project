const https = require('https');

const GOVERNANCE_KNOWLEDGE = `
You are GAIA (Governance AI Assistant), an AI-powered assistant for AIRGSS - AI Powered Rural Governance Support System.
You help rural citizens with Panchayat services. You support English, Hindi, and Marathi.

Services you help with:
- Complaint registration (roads, water, electricity, sanitation, health, education)
- Government scheme recommendations (PM Awas Yojana, PM Kisan, Ayushman Bharat, etc.)
- Tax and bill payments (property tax, water bill)
- Certificate requests (income, residence, birth certificates)
- Document upload and verification

Government Schemes:
- PM Awas Yojana: Housing for families with income < 3 lakhs
- PM Kisan Samman Nidhi: Rs 6000/year for farmers
- Ayushman Bharat: Free health coverage up to Rs 5 lakhs for BPL families
- PMJDY: Jan Dhan bank accounts for all
- Ujjwala Yojana: Free LPG for BPL women
- MGNREGA: 100 days employment guarantee

Be helpful, concise, and compassionate. For complex issues, guide users to the appropriate service module.
`;

exports.getChatbotResponse = async (message, history, language, user) => {
  try {
    const systemPrompt = GOVERNANCE_KNOWLEDGE + (user ? `\nUser: ${user.name}, Role: ${user.role}` : '');
    const messages = [...history.slice(-8), { role: 'user', content: message }];

    const body = JSON.stringify({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 500,
      system: systemPrompt,
      messages
    });

    return new Promise((resolve) => {
      const options = {
        hostname: 'api.anthropic.com',
        path: '/v1/messages',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': process.env.ANTHROPIC_API_KEY || '',
          'anthropic-version': '2023-06-01',
          'Content-Length': Buffer.byteLength(body)
        }
      };
      const req = https.request(options, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          try {
            const parsed = JSON.parse(data);
            if (parsed.content && parsed.content[0]) {
              resolve(parsed.content[0].text);
            } else {
              resolve(getFallbackResponse(message));
            }
          } catch { resolve(getFallbackResponse(message)); }
        });
      });
      req.on('error', () => resolve(getFallbackResponse(message)));
      req.write(body);
      req.end();
    });
  } catch (err) {
    return getFallbackResponse(message);
  }
};

function getFallbackResponse(message) {
  const lower = message.toLowerCase();
  if (lower.includes('complaint') || lower.includes('problem')) {
    return 'To file a complaint, go to the Complaints section and describe your issue. Our AI will classify and assign it to the right department automatically.';
  }
  if (lower.includes('scheme') || lower.includes('benefit')) {
    return 'To see government schemes you qualify for, complete your profile with income, age, and occupation details. Then visit the Schemes section for personalized recommendations.';
  }
  if (lower.includes('tax') || lower.includes('payment') || lower.includes('bill')) {
    return 'You can pay property tax, water bills, and local fees in the Payments section. We accept all major payment methods.';
  }
  if (lower.includes('certificate') || lower.includes('document')) {
    return 'You can request Income, Residence, and Birth certificates from the Documents section. Admin will verify and issue digitally.';
  }
  if (lower.includes('hello') || lower.includes('hi') || lower.includes('namaste')) {
    return 'Namaste! I am GAIA, your Governance AI Assistant. I can help you with complaints, schemes, payments, certificates and more. How can I assist you today?';
  }
  return 'I am here to help with all Panchayat services. You can ask me about complaints, government schemes, payments, or document requests.';
}
